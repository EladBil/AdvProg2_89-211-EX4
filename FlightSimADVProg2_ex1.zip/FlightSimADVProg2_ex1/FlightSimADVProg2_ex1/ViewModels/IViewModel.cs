﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlightSimADVProg2_ex1.ViewModels
{
    interface IViewModel
    {
        public void Initialize();
        public void StartAnimation();
    }
}
